class Member < ActiveRecord::Base
end
