require 'test_helper'

class AjaxHelperTest < ActionView::TestCase
end
