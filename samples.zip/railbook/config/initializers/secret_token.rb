# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Railbook::Application.config.secret_key_base = '69e1bc5e0c5dc1cf61f2e6c19914bad80e7c22c58e6a1be26d8cd820b6ca04a51f0cfb5aea637b50c669671a501b2f41ea37840651e0807dc6cee6d072d5af9b'
