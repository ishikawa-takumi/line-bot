class CreateReviews < ActiveRecord::Migration
  def change
    create_table :reviews do |t|
      t.references :book, index: true
      t.references :user, index: true
      t.text :body

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        execute 'ALTER TABLE reviews ADD CONSTRAINT fk_reviews_books FOREIGN KEY (book_id) REFERENCES books(id)'
      end
      dir.down do
        execute 'ALTER TABLE reviews DROP FOREIGN KEY fk_reviews_books'
      end
    end
  end

# up／downメソッドで書き替えた場合
#  def up
#    create_table :reviews do |t|
#      t.references :book, index: true
#      t.references :user, index: true
#      t.text :body

#      t.timestamps
#    end
#    execute 'ALTER TABLE reviews ADD CONSTRAINT fk_reviews_books FOREIGN KEY (book_id) REFERENCES books(id)'
#  end

#  def down
#    execute 'ALTER TABLE reviews DROP FOREIGN KEY fk_reviews_books'
#    drop_table :reviews
#  end
end
