require 'test_helper'

class Admin::BooksHelperTest < ActionView::TestCase
end
