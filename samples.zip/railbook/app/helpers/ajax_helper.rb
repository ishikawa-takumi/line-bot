module AjaxHelper
end
