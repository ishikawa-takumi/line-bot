class FanComment < ActiveRecord::Base
end
